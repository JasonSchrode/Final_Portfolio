function openNav() {
    document.getElementById("menu").style.height = "375px";
}